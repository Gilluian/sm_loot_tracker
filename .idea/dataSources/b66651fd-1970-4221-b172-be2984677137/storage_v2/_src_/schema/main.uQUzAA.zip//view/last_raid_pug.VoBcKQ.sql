CREATE VIEW last_raid_pug AS
                        SELECT p.name, i.item_name, lr.date
                        FROM loot_record lr
                        INNER JOIN players p ON lr.winner_id = p.sql_id
                        INNER JOIN items i ON lr.item_id = i.wow_itemid
                        WHERE lr.date = (SELECT max(date) from loot_record)
                        AND p.name != '_disenchanted'
                        AND guild_rank IS NULL;

